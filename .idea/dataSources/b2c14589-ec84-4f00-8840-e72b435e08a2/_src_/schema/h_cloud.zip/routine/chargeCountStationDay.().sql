CREATE PROCEDURE chargeCountStationDay()
  BEGIN

DECLARE orderId varchar(60);
DECLARE stationId varchar(6);
DECLARE chargerId varchar(8);
DECLARE y int DEFAULT 0;
DECLARE m int DEFAULT 0;
DECLARE d int DEFAULT 0;
DECLARE count int DEFAULT 0;
DECLARE time int DEFAULT 0;
DECLARE done int DEFAULT 0;
DECLARE dataCount int DEFAULT 0;
DECLARE orderCount int DEFAULT 0;

DECLARE cur CURSOR FOR
SELECT order_id,charger_id,SUBSTR(charger_id, 1, 6) station_id, YEAR (FROM_UNIXTIME(begin_time)) y_, MONTH (FROM_UNIXTIME(begin_time)) m_,
	DAY (FROM_UNIXTIME(begin_time)) d_, UNIX_TIMESTAMP(CONCAT(YEAR (FROM_UNIXTIME(begin_time)),'-',MONTH (FROM_UNIXTIME(begin_time)),'-',DAY (FROM_UNIXTIME(begin_time)))) time_ FROM charge_orders ;
 DECLARE CONTINUE HANDLER FOR NOT FOUND SET done=1;

OPEN cur;
	posLoop:LOOP
			IF done=1 THEN
				LEAVE posLoop;
			END IF;
	FETCH cur INTO orderId,chargerId,stationId,y,m,d,time;
		SET dataCount=0;
		SELECT count(*) INTO dataCount FROM elec_charge_count_station_day WHERE station_id=stationId AND year=y AND month=m AND day=d limit 1;
		IF dataCount=0 THEN
			INSERT INTO elec_charge_count_station_day (station_id,year,month,day,charge_count,time) VALUES (stationId,y,m,d,count,time);
		ELSE
			UPDATE elec_charge_count_station_day SET charge_count=charge_count+1 WHERE station_id=stationId AND year=y AND month=m AND day=d;
		END IF;

		SET orderCount=0;
	  SELECT count(*) INTO orderCount FROM charge_orders_statistics WHERE order_id=orderId limit 1;
		IF orderCount=0 THEN
			INSERT INTO charge_orders_statistics (order_id,charger_id,station_id,charge_count_station_day) VALUES (orderId,chargerId,stationId,1);
		ELSE
			UPDATE charge_orders_statistics SET charge_count_station_day=1 WHERE order_id=orderId;
		END IF;
	END LOOP posLoop;
CLOSE cur;
END;

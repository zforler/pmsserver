CREATE PROCEDURE vehicle_day(IN p_start INT(10), IN p_end INT(10), IN p_operator VARCHAR(4))
  BEGIN
	DECLARE start_time INT(10);
	DEClARE p_year INT;
	DECLARE p_month INT;
	DECLARE p_day INT;
	DECLARE p_operator_id varchar(4) default '';
	SET start_time = p_start;
	SET p_operator_id = p_operator;
    WHILE start_time < p_end DO
		INSERT INTO h_cloud.charge_orders_tmp SELECT
			co.order_id,
			substring(co.charger_id, 1, 4),
			substring(co.charger_id, 1, 6),
			co.user_id,
			co.vehicle_id,
			co.card_id,
			co.charge_time,
			co.total_energy,
			co.total_elec_cost,
			co.tip_energy,
			co.tip_elec_cost,
			co.peak_energy,
			co.peak_elec_cost,
			co.normal_energy,
			co.normal_elec_cost,
			co.valley_energy,
			co.valley_elec_cost
		FROM
			h_cloud.charge_orders co
		LEFT JOIN h_cloud.vehicle v ON co.vehicle_id=v.vehicle_id
		WHERE
			v.operator_id = p_operator_id
		AND co.vehicle_id is not null	
		AND	co.begin_time >= start_time
		AND co.begin_time < start_time + 86400 
		AND co.total_energy < 30000
		AND co.total_elec_cost < 600 ; INSERT INTO h_cloud.elec_cost_vehicle_day (
			vehicle_id,
			total_time,
			total_energy,
			total_elec_cost,
			tip_energy,
			tip_elec_cost,
			peak_energy,
			peak_elec_cost,
			normal_energy,
			normal_elec_cost,
			valley_energy,
			valley_elec_cost,
			YEAR,
			MONTH,
			DAY
		) SELECT
			vehicle_id,
			sum(charge_time),
			sum(total_energy),
			sum(total_elec_cost),
			sum(tip_energy),
			sum(tip_elec_cost),
			sum(peak_energy),
			sum(peak_elec_cost),
			sum(normal_energy),
			sum(normal_elec_cost),
			sum(valley_energy),
			sum(valley_elec_cost),
			YEAR (FROM_UNIXTIME(start_time+36000)),
			MONTH (FROM_UNIXTIME(start_time+36000)),
			DAY (FROM_UNIXTIME(start_time+36000))
		FROM
			h_cloud.charge_orders_tmp
		WHERE
			vehicle_id IS NOT NULL
		GROUP BY
			vehicle_id ;
			
		SET p_year = YEAR (FROM_UNIXTIME(start_time+36000));
		SET p_month = MONTH (FROM_UNIXTIME(start_time+36000));
		SET p_day = DAY (FROM_UNIXTIME(start_time+36000));
		
		INSERT INTO h_cloud.elec_cost_vehicle_day (
					vehicle_id,
					total_time,
					total_energy,
					total_elec_cost,
					tip_energy,
					tip_elec_cost,
					peak_energy,
					peak_elec_cost,
					normal_energy,
					normal_elec_cost,
					valley_energy,
					valley_elec_cost,
					YEAR,
					MONTH,
					DAY
				) select v.vehicle_id,0,0,0.00,0,0.00,0,0.00,0,0.00,0,0.00,p_year,p_month,p_day from vehicle v where v.operator_id = p_operator_id and v.vehicle_id not in (
					select e.vehicle_id from elec_cost_vehicle_day e where e.year = p_year and e.month=p_month and e.day=p_day
					);
		SET start_time = start_time + 86400 ; 
		TRUNCATE TABLE h_cloud.charge_orders_tmp;
	END	WHILE;
	
END;

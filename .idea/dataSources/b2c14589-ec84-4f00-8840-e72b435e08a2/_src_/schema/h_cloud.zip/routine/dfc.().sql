CREATE PROCEDURE dfc()
  BEGIN
DECLARE codet int;
DECLARE namet VARCHAR(255);
declare done int; 
DECLARE devicefaultcode CURSOR FOR
	SELECT code,name FROM device_fault_code;
 DECLARE CONTINUE HANDLER FOR NOT FOUND SET done=1;

OPEN devicefaultcode;
	posLoop:LOOP
			IF done=1 THEN
 		LEAVE posLoop;
 	END IF;

	FETCH devicefaultcode INTO codet,namet;
		UPDATE device_fault SET fault_desc=namet WHERE code=codet ;
	END LOOP posLoop;
CLOSE devicefaultcode;
END;

CREATE PROCEDURE operator_day(IN p_start INT(10), IN p_end INT(10))
  BEGIN
    
	DECLARE start_time INT(10);
	SET start_time = p_start;
    WHILE start_time < p_end DO
		INSERT INTO h_cloud.charge_orders_tmp SELECT
			order_id,
			substring(charger_id, 1, 4),
			substring(charger_id, 1, 6),
			user_id,
			vehicle_id,
			card_id,
			charge_time,
			total_energy,
			total_elec_cost,
			tip_energy,
			tip_elec_cost,
			peak_energy,
			peak_elec_cost,
			normal_energy,
			normal_elec_cost,
			valley_energy,
			valley_elec_cost
		FROM
			h_cloud.charge_orders
		WHERE
			`begin_time` >= start_time
		AND begin_time < start_time + 86400 
		
		
		AND total_energy < 30000
		AND total_elec_cost < 600 ; INSERT INTO h_cloud.elec_cost_operator_day (
			operator_id,
			total_time,
			total_energy,
			total_elec_cost,
			tip_energy,
			tip_elec_cost,
			peak_energy,
			peak_elec_cost,
			normal_energy,
			normal_elec_cost,
			valley_energy,
			valley_elec_cost,
			YEAR,
			MONTH,
			DAY
		) SELECT
			operator_id,
			sum(charge_time),
			sum(total_energy),
			sum(total_elec_cost),
			sum(tip_energy),
			sum(tip_elec_cost),
			sum(peak_energy),
			sum(peak_elec_cost),
			sum(normal_energy),
			sum(normal_elec_cost),
			sum(valley_energy),
			sum(valley_elec_cost),
			YEAR (FROM_UNIXTIME(start_time+36000)),
			MONTH (FROM_UNIXTIME(start_time+36000)),
			DAY (FROM_UNIXTIME(start_time+36000))
		FROM
			h_cloud.charge_orders_tmp
		WHERE
			operator_id IS NOT NULL
		GROUP BY
			operator_id ;
		SET start_time = start_time + 86400 ; 
		TRUNCATE TABLE h_cloud.charge_orders_tmp;
	END	WHILE;
END;

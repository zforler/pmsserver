CREATE PROCEDURE order_day(IN p_start INT(10), IN p_end INT(10))
  BEGIN
    
	DECLARE start_time INT(10);
	DEClARE p_year INT;
	DECLARE p_month INT;
	DECLARE p_day INT;
	SET start_time = p_start;
    WHILE start_time < p_end DO
		INSERT INTO h_cloud.charge_orders_tmp 
		SELECT
			co.order_id,
			co.charger_id,
			s.operator_id,
			s.station_id,
			v.enterprise_id,
			co.user_id,
			co.vehicle_id,
			co.card_id,
			co.charge_time,
			co.total_energy,
			co.total_elec_cost,
			IFNULL((select sum(cri.end_time - cri.begin_time) from charge_record_item cri 
			LEFT JOIN charge_record cr on cri.session_id=cr.session_id 
			where cr.order_id = co.order_id and cri.rate_type = 1 and cri.begin_time < cri.end_time),0),
			co.tip_energy,
			co.tip_elec_cost,
			IFNULL((select sum(cri.end_time - cri.begin_time) from charge_record_item cri 
			LEFT JOIN charge_record cr on cri.session_id=cr.session_id 
			where cr.order_id = co.order_id and cri.rate_type = 2 and cri.begin_time < cri.end_time),0),
			co.peak_energy,
			co.peak_elec_cost,
			IFNULL((select sum(cri.end_time - cri.begin_time) from charge_record_item cri 
			LEFT JOIN charge_record cr on cri.session_id=cr.session_id 
			where cr.order_id = co.order_id and cri.rate_type = 3 and cri.begin_time < cri.end_time),0),
			co.normal_energy,
			co.normal_elec_cost,
			IFNULL((select sum(cri.end_time - cri.begin_time) from charge_record_item cri 
			LEFT JOIN charge_record cr on cri.session_id=cr.session_id 
			where cr.order_id = co.order_id and cri.rate_type = 4 and cri.begin_time < cri.end_time),0),
			co.valley_energy,
			co.valley_elec_cost,
			co.startup_source
		FROM
			h_cloud.charge_orders co
		LEFT JOIN h_cloud.vehicle v on co.vehicle_id=v.vehicle_id
		LEFT JOIN h_cloud.charger c on co.charger_id=c.charger_id
		LEFT JOIN h_cloud.station s on c.station_id=s.station_id
		WHERE
			co.begin_time >= start_time
		AND co.begin_time < start_time + 86400
		
		
		
		AND co.total_energy < 30000
		AND co.total_energy > 0
		AND co.total_elec_cost < 600; 
		
		
		INSERT INTO h_cloud.charge_orders_statistics 
		SELECT
			co.order_id,
			co.charger_id,
			0, 0, 0, 0,
			co.user_id,0, 0,
			co.vehicle_id,0,0,
			co.card_id,0,0,
			s.operator_id,0,0,
			s.station_id,0,0,
			v.enterprise_id,0,0
		FROM
			h_cloud.charge_orders co
		LEFT JOIN h_cloud.vehicle v on co.vehicle_id=v.vehicle_id
		LEFT JOIN h_cloud.charger c on co.charger_id=c.charger_id
		LEFT JOIN h_cloud.station s on c.station_id=s.station_id
		WHERE
			co.begin_time >= start_time
		AND co.begin_time < start_time + 86400
		
		
		
		AND co.total_energy < 30000
		AND co.total_energy > 0
		AND co.total_elec_cost < 600; 
		
		SET p_year = YEAR (FROM_UNIXTIME(start_time+36000));
		SET p_month = MONTH (FROM_UNIXTIME(start_time+36000));
		SET p_day = DAY (FROM_UNIXTIME(start_time+36000));
		
		
		
		INSERT INTO h_cloud.elec_cost_operator_day (
			operator_id,
			total_time,
			total_energy,
			total_elec_cost,
			tip_time,
			tip_energy,
			tip_elec_cost,
			peak_time,
			peak_energy,
			peak_elec_cost,
			normal_time,
			normal_energy,
			normal_elec_cost,
			valley_time,
			valley_energy,
			valley_elec_cost,
			YEAR,
			MONTH,
			DAY
		) SELECT
			operator_id,
			sum(charge_time),
			sum(total_energy),
			sum(total_elec_cost),
			sum(tip_time),
			sum(tip_energy),
			sum(tip_elec_cost),
			sum(peak_time),
			sum(peak_energy),
			sum(peak_elec_cost),
			sum(normal_time),
			sum(normal_energy),
			sum(normal_elec_cost),
			sum(valley_time),
			sum(valley_energy),
			sum(valley_elec_cost),
			p_year,
			p_month,
			p_day
		FROM
			h_cloud.charge_orders_tmp
		WHERE
			operator_id IS NOT NULL
		GROUP BY
			operator_id ;
			
		
		INSERT INTO h_cloud.elec_cost_operator_day (
					operator_id,
					total_time,
					total_energy,
					total_elec_cost,
					tip_energy,
					tip_elec_cost,
					peak_energy,
					peak_elec_cost,
					normal_energy,
					normal_elec_cost,
					valley_energy,
					valley_elec_cost,
					YEAR,
					MONTH,
					DAY
				) select o.operator_id,0,0,0.00,0,0.00,0,0.00,0,0.00,0,0.00,p_year,p_month,p_day from operator_info o where o.operator_id  not in (
					select e.operator_id from elec_cost_operator_day e where e.year = p_year and e.month=p_month and e.day=p_day
					);	
			
		
		UPDATE h_cloud.charge_orders_statistics cos
		SET cos.operator_day = 1
		WHERE cos.operator_id IS NOT NULL
		AND cos.order_id in (
			SELECT cot.order_id from h_cloud.charge_orders_tmp cot
		);
		
		
		
		INSERT INTO h_cloud.elec_cost_station_day (
			station_id,
			total_time,
			total_energy,
			total_elec_cost,
			tip_time,
			tip_energy,
			tip_elec_cost,
			peak_time,
			peak_energy,
			peak_elec_cost,
			normal_time,
			normal_energy,
			normal_elec_cost,
			valley_time,
			valley_energy,
			valley_elec_cost,
			YEAR,
			MONTH,
			DAY
		) SELECT
			station_id,
			sum(charge_time),
			sum(total_energy),
			sum(total_elec_cost),
			sum(tip_time),
			sum(tip_energy),
			sum(tip_elec_cost),
			sum(peak_time),
			sum(peak_energy),
			sum(peak_elec_cost),
			sum(normal_time),
			sum(normal_energy),
			sum(normal_elec_cost),
			sum(valley_time),
			sum(valley_energy),
			sum(valley_elec_cost),
			p_year,
			p_month,
			p_day
		FROM
			h_cloud.charge_orders_tmp
		WHERE
			station_id IS NOT NULL
		GROUP BY
			station_id;
			
		
		INSERT INTO h_cloud.elec_cost_station_day (
					station_id,
					total_time,
					total_energy,
					total_elec_cost,
					tip_energy,
					tip_elec_cost,
					peak_energy,
					peak_elec_cost,
					normal_energy,
					normal_elec_cost,
					valley_energy,
					valley_elec_cost,
					YEAR,
					MONTH,
					DAY
				) select s.station_id,0,0,0.00,0,0.00,0,0.00,0,0.00,0,0.00,p_year,p_month,p_day from station s where s.station_id  not in (
					select e.station_id from elec_cost_station_day e where e.year = p_year and e.month=p_month and e.day=p_day
					);	
			
		
		UPDATE h_cloud.charge_orders_statistics cos
		SET cos.station_day = 1
		WHERE cos.station_id IS NOT NULL
		AND cos.order_id in (
			SELECT cot.order_id from h_cloud.charge_orders_tmp cot
		);
		
		
		INSERT INTO h_cloud.elec_cost_enterprise_day (
			enterprise_id,
			total_time,
			total_energy,
			total_elec_cost,
			tip_time,
			tip_energy,
			tip_elec_cost,
			peak_time,
			peak_energy,
			peak_elec_cost,
			normal_time,
			normal_energy,
			normal_elec_cost,
			valley_time,
			valley_energy,
			valley_elec_cost,
			YEAR,
			MONTH,
			DAY
		) SELECT
			enterprise_id,
			sum(charge_time),
			sum(total_energy),
			sum(total_elec_cost),
			sum(tip_time),
			sum(tip_energy),
			sum(tip_elec_cost),
			sum(peak_time),
			sum(peak_energy),
			sum(peak_elec_cost),
			sum(normal_time),
			sum(normal_energy),
			sum(normal_elec_cost),
			sum(valley_time),
			sum(valley_energy),
			sum(valley_elec_cost),
			p_year,
			p_month,
			p_day
		FROM
			h_cloud.charge_orders_tmp
		WHERE
			enterprise_id IS NOT NULL
		GROUP BY
			enterprise_id;
			
		
		INSERT INTO h_cloud.elec_cost_enterprise_day (
					enterprise_id,
					total_time,
					total_energy,
					total_elec_cost,
					tip_energy,
					tip_elec_cost,
					peak_energy,
					peak_elec_cost,
					normal_energy,
					normal_elec_cost,
					valley_energy,
					valley_elec_cost,
					YEAR,
					MONTH,
					DAY
				) select e.enterprise_id,0,0,0.00,0,0.00,0,0.00,0,0.00,0,0.00,p_year,p_month,p_day from enterprise e where e.enterprise_id  not in (
					select e.enterprise_id from elec_cost_enterprise_day e where e.year = p_year and e.month=p_month and e.day=p_day
					);	
			
		
		UPDATE h_cloud.charge_orders_statistics cos
		SET cos.enterprise_day = 1
		WHERE cos.enterprise_id IS NOT NULL
		AND cos.order_id in (
			SELECT cot.order_id from h_cloud.charge_orders_tmp cot
		);
		
		
		
		INSERT INTO h_cloud.elec_cost_user_day (
			user_id,
			total_time,
			total_energy,
			total_elec_cost,
			tip_time,
			tip_energy,
			tip_elec_cost,
			peak_time,
			peak_energy,
			peak_elec_cost,
			normal_time,
			normal_energy,
			normal_elec_cost,
			valley_time,
			valley_energy,
			valley_elec_cost,
			YEAR,
			MONTH,
			DAY
		) SELECT
			user_id,
			sum(charge_time),
			sum(total_energy),
			sum(total_elec_cost),
			sum(tip_time),
			sum(tip_energy),
			sum(tip_elec_cost),
			sum(peak_time),
			sum(peak_energy),
			sum(peak_elec_cost),
			sum(normal_time),
			sum(normal_energy),
			sum(normal_elec_cost),
			sum(valley_time),
			sum(valley_energy),
			sum(valley_elec_cost),
			p_year,
			p_month,
			p_day
		FROM
			h_cloud.charge_orders_tmp
		WHERE
			user_id IS NOT NULL
		GROUP BY
			user_id;
			
			
		
		UPDATE h_cloud.charge_orders_statistics cos
		SET cos.user_day = 1
		WHERE cos.user_id IS NOT NULL
		AND cos.order_id in (
			SELECT cot.order_id from h_cloud.charge_orders_tmp cot
		);
		
		
		
		INSERT INTO h_cloud.elec_cost_vehicle_day (
			vehicle_id,
			total_time,
			total_energy,
			total_elec_cost,
			tip_time,
			tip_energy,
			tip_elec_cost,
			peak_time,
			peak_energy,
			peak_elec_cost,
			normal_time,
			normal_energy,
			normal_elec_cost,
			valley_time,
			valley_energy,
			valley_elec_cost,
			YEAR,
			MONTH,
			DAY
		) SELECT
			vehicle_id,
			sum(charge_time),
			sum(total_energy),
			sum(total_elec_cost),
			sum(tip_time),
			sum(tip_energy),
			sum(tip_elec_cost),
			sum(peak_time),
			sum(peak_energy),
			sum(peak_elec_cost),
			sum(normal_time),
			sum(normal_energy),
			sum(normal_elec_cost),
			sum(valley_time),
			sum(valley_energy),
			sum(valley_elec_cost),
			p_year,
			p_month,
			p_day
		FROM
			h_cloud.charge_orders_tmp
		WHERE
			vehicle_id IS NOT NULL
		GROUP BY
			vehicle_id;
			
	
			
		
		UPDATE h_cloud.charge_orders_statistics cos
		SET cos.vehicle_day = 1
		WHERE cos.vehicle_id IS NOT NULL
		AND cos.order_id in (
			SELECT cot.order_id from h_cloud.charge_orders_tmp cot
		);
		
		
		INSERT INTO h_cloud.elec_cost_card_day (
			card_id,
			total_time,
			total_energy,
			total_elec_cost,
			tip_time,
			tip_energy,
			tip_elec_cost,
			peak_time,
			peak_energy,
			peak_elec_cost,
			normal_time,
			normal_energy,
			normal_elec_cost,
			valley_time,
			valley_energy,
			valley_elec_cost,
			YEAR,
			MONTH,
			DAY
		) SELECT
			card_id,
			sum(charge_time),
			sum(total_energy),
			sum(total_elec_cost),
			sum(tip_time),
			sum(tip_energy),
			sum(tip_elec_cost),
			sum(peak_time),
			sum(peak_energy),
			sum(peak_elec_cost),
			sum(normal_time),
			sum(normal_energy),
			sum(normal_elec_cost),
			sum(valley_time),
			sum(valley_energy),
			sum(valley_elec_cost),
			p_year,
			p_month,
			p_day
		FROM
			h_cloud.charge_orders_tmp
		WHERE
			card_id IS NOT NULL
		GROUP BY
			card_id;
			
		
			
		
		UPDATE h_cloud.charge_orders_statistics cos
		SET cos.card_day = 1
		WHERE cos.card_id IS NOT NULL
		AND cos.order_id in (
			SELECT cot.order_id from h_cloud.charge_orders_tmp cot
		);
		
		
		
		INSERT INTO h_cloud.startup_source_statistics (
			id,
			operator_id,
			station_id,
			charger_id,
			startup_source,
			startup_source_count,
			year,
			month,
			day
		) SELECT
			CONCAT(charger_id,startup_source,p_year,LPAD(p_month, 2, 0),LPAD(p_day, 2, 0)),
			operator_id,
			station_id,
			charger_id,
			startup_source,
			count(order_id),
			p_year,
			p_month,
			p_day
		FROM
			h_cloud.charge_orders_tmp
		WHERE
			startup_source IS NOT NULL
		GROUP BY
			charger_id,startup_source;
			
			
		
		UPDATE h_cloud.charge_orders_statistics cos
		SET cos.startup_source = 1
		WHERE cos.startup_source IS NOT NULL
		AND cos.order_id in (
			SELECT cot.order_id from h_cloud.charge_orders_tmp cot
		);
		
		SET start_time = start_time + 86400 ; 
		TRUNCATE TABLE h_cloud.charge_orders_tmp;
	END	WHILE;
END;

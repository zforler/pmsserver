CREATE PROCEDURE accountdata()
  BEGIN

DECLARE accountId VARCHAR(255);
declare done int; 
DECLARE accountData CURSOR FOR
	SELECT account_id FROM account WHERE `name`='';
 DECLARE CONTINUE HANDLER FOR NOT FOUND SET done=1;

OPEN accountData;
	posLoop:LOOP
			IF done=1 THEN
 		LEAVE posLoop;
 	END IF;

	FETCH accountData INTO accountId;
		update account SET name=(SELECT CONCAT('涓?汉璐︽埛',SUBSTR(user_id FROM 5 FOR 12)+0) 
FROM account_relevancy WHERE account_id=accountId AND end_time=0) WHERE account_id=accountId;
	END LOOP posLoop;
CLOSE accountData;
END;

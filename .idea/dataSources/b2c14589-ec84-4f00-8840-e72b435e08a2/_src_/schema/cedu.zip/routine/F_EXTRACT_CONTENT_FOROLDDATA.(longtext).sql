CREATE FUNCTION F_EXTRACT_CONTENT_FOROLDDATA(HTML_SRC LONGTEXT)
  RETURNS LONGTEXT
  BEGIN
	DECLARE temp LONGTEXT DEFAULT '';
    set temp = EXTRACTVALUE (HTML_SRC,'/root/p[@style ="TEXT-INDENT: 28px"]');
    IF (temp is null or temp = '') THEN
        set temp = EXTRACTVALUE (HTML_SRC,'/root/p[@style ="text-indent: 2em;"]');
    end if;
    IF (temp is null or temp = '') THEN
        set temp = EXTRACTVALUE (HTML_SRC,'/root/p[@style ="text-indent: 2em"]');
    end if;
    IF (temp is null or temp = '') THEN
        set temp = EXTRACTVALUE (HTML_SRC,'/root/p[@style ="TEXT-INDENT: 28px;"]');
    end if;
    IF (temp is null or temp = '') THEN
        set temp = EXTRACTVALUE (HTML_SRC,'/root/p');
    end if;
    return temp;
END;

CREATE FUNCTION queryChildrenAreaInfo(areaId INT)
  RETURNS VARCHAR(4000)
  BEGIN

DECLARE sTemp VARCHAR(4000);

DECLARE sTempChd VARCHAR(4000);


SET sTemp = '$';

SET sTempChd = cast(areaId as char);


WHILE sTempChd is not NULL DO

SET sTemp = CONCAT(sTemp,',',sTempChd);

SELECT group_concat(ID) INTO sTempChd FROM t_res_composion where FIND_IN_SET(ORIGINAL_ID,sTempChd)>0;

END WHILE;

return sTemp;


END;

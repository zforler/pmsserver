CREATE FUNCTION F_GETUSERNAME(ACCOUNT_ALIAS VARCHAR(100), NAME VARCHAR(100), ACCOUNT VARCHAR(100))
  RETURNS VARCHAR(100)
  BEGIN
  if (ACCOUNT_ALIAS is not null and ACCOUNT_ALIAS<>'') then
	return ACCOUNT_ALIAS;
  end if;
  if (NAME is not null and NAME<>'') then
	return NAME;
  end if;
  if (ACCOUNT is not null and ACCOUNT<>'') then
	return ACCOUNT;
  end if;
  return '';
END;
